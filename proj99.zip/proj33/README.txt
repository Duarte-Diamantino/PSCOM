
Exemplos de programas com comunica��o e sincroniza��o entre processos
usando sockets (sockets unix datagrama, sockets unix stream) -- CRA
----------------------------------------------------------------------

# Sockets unix datagrama:

"sdsrv.c" e "sdcli.c" -- Exemplo de utiliza��o de sockets unix
   datagrama na comunica��o entre 2 processos independentes
   hierarquicamente (Cliente, Servidor).  Executar primeiro (em
   "background" ou noutra janela) o programa Servidor ("sdsrv"), e
   depois o programa Cliente ("sdcli").


# Sockets unix stream:

"sssrv.c" e "sscli.c" -- Exemplo de utiliza��o de sockets unix stream
   na comunica��o entre 2 processos independentes hierarquicamente
   (Cliente, Servidor).  Executar primeiro (em "background" ou noutra
   janela) o programa Servidor ("sssrv"), e depois o programa Cliente
   ("sscli").
