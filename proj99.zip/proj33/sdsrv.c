/***************************************************************************
| File: monitor.c
|
| Autor: Carlos Almeida (IST), from work by Jose Rufino (IST/INESC), 
|        from an original by Leendert Van Doorn
| Data:  Nov 2002
***************************************************************************/
#include "ctrl_acess.h"

#define NCOMMANDS  (sizeof(commands)/sizeof(struct command_d))
#define SERVNAME "/SERV"
#define TXTSIZE 10

/*Incializacoes*/
void cria_ficheiro(void);
void inicia_srv_cli(void);
void env_serv (int, char** );


/*Comandos a executar - interface*/
void cmd_cuti (void );
void cmd_luti (void );
void cmd_euti (void );
void cmd_muti (void );
void cmd_lac (void);
void cmd_tser (void );
void cmd_cep (void );
void cmd_mep (void );
void cmd_tctl (void );
void cmd_sos  (void); 
void cmd_sair (void);


char portas_abertas[3];

/***************************************

Variaveis da queue para abrir porta

***************************************/

int mqids, mqidc, i;
struct mq_attr ma;
struct {
    char    id[TXTSIZE];
    char 	porta;
    char    mtext[10];   
  } msg;

/***************************************

Variaveis da queue para mandar comandos
			sobre o CTLP

***************************************/

int mqids2, mqidc2, j;
struct mq_attr ma2;
struct {
    char    id[TXTSIZE];
    char    mtext[10];   
  } msg2;
char queue1_id[10];


/***************************************

Variaveis da queue para mandar comandos
			sobre o CTLP

***************************************/

struct 	command_d {
  void  (*cmd_fnct)(void);
  char*	cmd_name;
} const commands[] = {
	{cmd_cuti, "cuti"},
	{cmd_luti, "luti"},
	{cmd_euti, "euti"},
	{cmd_muti, "muti"},	
  	{cmd_lac, "lac"},	
  	{cmd_tser, "tser"},
  	{cmd_cep, "cep"},
  	{cmd_mep, "mep"},
	{cmd_tctl, "tctl"}
};

linha_cmd u1;

pthread_t  thread_integes;

struct sockaddr_un my_addr;
socklen_t addrlen;
struct sockaddr_un from;
socklen_t fromlen;

struct sockaddr_un my_addr;
socklen_t addrlen;
struct sockaddr_un to;
socklen_t tolen;


uti_t u, u_v[UMAX];
uti_t *pa;
int sd;
int mfd;
int linha_ficheiro = 0;


reg_t reg;
reg_t *pa2; 
int sd_reg;
int mfd_reg;
int linha_ficheiro_reg = 0;

pthread_mutex_t mux;

/*-------------------------------------------------------------------------+
* 
* Funcao: cria_ficheiro
*
+-------------------------------------------------------------------------*/
void cria_ficheiro(void){
	linha_ficheiro = 0;

/* abrir / criar ficheiro */
	if ((mfd=open(FUTI, O_RDWR|O_CREAT, 0666 )) < 0) {  
	    perror("Erro a criar ficheiro");
	    exit(-1);
	}else {
/* definir tamanho do ficheiro */
		if (ftruncate(mfd, UMAX*sizeof(u)) < 0) {  
      		perror("Erro no ftruncate");
      		exit(-1);
    	}
  	}
/* mapear ficheiro */
  	if ((pa=mmap(NULL, sizeof(u), PROT_READ|PROT_WRITE, MAP_SHARED, mfd, 0)) < (uti_t *)0) {
    	perror("Erro em mmap");
    	exit(-1);
  	}
/*Mostra conteudo no ficheiro*/  	
  	while((strcmp(pa[linha_ficheiro].id, "") != 0)){
		printf("%d	",linha_ficheiro);
		printf( "%s	",pa[linha_ficheiro].id);
		printf( "%s	",pa[linha_ficheiro].nome);
		printf( "%s\n",pa[linha_ficheiro].port);
		linha_ficheiro++;
	} 
	printf("linhas do ficheiro: %d\n", linha_ficheiro);	
  	/*while(strcmp(pa[i].id, "0"))*/

}

/*-------------------------------------------------------------------------+
* 
* Funcao: cria_ficheiro
*
+-------------------------------------------------------------------------*/
void cria_ficheiro_reg(void){
	
		
	linha_ficheiro_reg = 0;
	
	/* abrir / criar ficheiro */
	if ((mfd_reg=open(FREG, O_RDWR|O_CREAT, 0666 )) < 0) {  
	    perror("Erro a criar ficheiro");
	    exit(-1);
	}else {
		/* definir tamanho do ficheiro */
    	 if (ftruncate(mfd_reg, NREG*sizeof(reg)) < 0) {  
      		perror("Erro no ftruncate");
      		exit(-1);
    	}
  	}
  	/* mapear ficheiro */
  	if ((pa2=mmap(NULL, sizeof(reg), PROT_READ|PROT_WRITE, MAP_SHARED, mfd_reg, 0)) < (reg_t *)0) {
    	perror("Erro em mmap");
    	exit(-1);
  	}
  	 
	printf("linhas do ficheiro: %d\n", linha_ficheiro_reg);

}

/*-------------------------------------------------------------------------+
* 
* Funcao: inicia_srv_intges
*
+-------------------------------------------------------------------------*/
void inicia_srv_intges(void){
	if ((sd = socket(AF_UNIX, SOCK_DGRAM, 0)) < 0 ) {
    		perror("Erro a criar socket"); exit(-1);
  	}    
  	
  	my_addr.sun_family = AF_UNIX;
  	memset(my_addr.sun_path, 0, sizeof(my_addr.sun_path));
  	strcpy(my_addr.sun_path, SERVS);
  	addrlen = sizeof(my_addr.sun_family) + strlen(my_addr.sun_path);

  	if (bind(sd, (struct sockaddr *)&my_addr, addrlen) < 0 ) {
    		perror("Erro no bind"); exit(-1);
  	}
  
  	fromlen = sizeof(from);
  	if (recvfrom(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, &fromlen) < 0) {
    		perror("Erro no recvfrom");
  	}
	printf("comando: %s\nrecebeu: %s\nrecebeu: %s\nrecebeu: %s\n", u1.cmd, u1.id, u1.nome, u1.portas);
  	printf("\nSRV> recebeu de int.ges\n");
}

/*-------------------------------------------------------------------------+
* 
* Funcao: inicia_srv_ctlp
*
+-------------------------------------------------------------------------*/
void env_ctlp(void){
	
	printf("%s\n", msg.id);
	printf("%c\n", msg.porta);	
	printf("%s\n", msg.mtext);
	
    if ((mqidc=mq_open(msg.id, O_RDWR)) < 0) {
      perror("Servidor: Erro a associar a queue cliente");
    }
    else {
      printf("Servidor vai enviar\n");
      if (mq_send(mqidc, (char *)&msg, sizeof(msg), 0) < 0) {
	perror("Servidor: erro a enviar mensagem");
      }
    }
}

/*-------------------------------------------------------------------------+
* 
* Funcao: inicia_srv_ctlp
*
+-------------------------------------------------------------------------*/
void rcb_ctlp(void){
	 printf("a receber\n");
    if ((mqids=mq_open(SERVNAME, O_RDWR|O_CREAT, 0666, &ma)) < 0) {
    	perror("Servidor: Erro a criar queue servidor");
    	exit(-1);
  	}
	printf("Servidor vai receber\n");
  	if (mq_receive(mqids, (char *)&msg, sizeof(msg), NULL) < 0) {
    	perror("Servidor: erro a receber mensagem");
  	}else{      	
      	printf("recebeu: %c\n",msg.porta);
	}
}


/*-------------------------------------------------------------------------+
* 
* Funcao: inicia_srv_ctlp
*
+-------------------------------------------------------------------------*/
void srv_vrfporta1(void){
	
	printf("recebe a porta\n");
	rcb_ctlp();
	for(int i; i == 0; i++){
		/*if(strcmp(portas_abertas[i], msg.porta) == 0){*/
		if((portas_abertas[i] == msg.porta) || (portas_abertas[i] == msg.porta) || (portas_abertas[i] == msg.porta)){
			printf("SRV> erro porta ja existe\n");
			strcpy(msg.mtext, "erro");
			env_ctlp();		
			return;
		} 
	}
	printf("Porta %c criada com sucesso\n", msg.porta);
	strcpy(msg.mtext, "porta");
	env_ctlp();
}


/*-------------------------------------------------------------------------+
* 
* Funcao: inicia_srv_ctlp
*
+-------------------------------------------------------------------------*/
void srv_vrfporta2(void){
	time_t t;
  	struct tm tm;
  	struct timespec ts;
  	char time [50];

  	clock_gettime(CLOCK_REALTIME, &ts);

  	t = ts.tv_sec;
  	memset(&tm, 0, sizeof(struct tm));
  	localtime_r (&t, &tm);
  	strftime(time, sizeof(time), "%d/%m/%Y %H:%M:%S", &tm);
  	printf ("Data:%s %ld \n", time, t);

	
	rcb_ctlp();
	for(i = 0; i< linha_ficheiro; i++){
		/*Testa se o id existe*/
		printf("\nSRV> id:%s e %s\n", pa[i].id, msg.mtext);
		if(strcmp(msg.mtext, pa[i].id) == 0){				
			printf("\nSRV> <id> encontrado -> pode abrir a porta\n");
			strcpy(reg.id, msg.mtext);
			strcpy(msg.mtext, "abre");
  			printf("porta: %c\n", msg.porta);
  			reg.p = msg.porta; 
  			clock_gettime(CLOCK_REALTIME, &reg.t);
  			
  			
  			t = reg.t.tv_sec;
  			memset(&tm, 0, sizeof(struct tm));
  			localtime_r (&t, &tm);
  			strftime(time, sizeof(time), "%d/%m/%Y %H:%M:%S", &tm);
  			printf ("Data:%s %ld \n", time,  reg.t.tv_sec);

  			
  			
  			printf("aqui3\n");
  			pa2[linha_ficheiro_reg]= reg;
  			printf("aqui4\n");
  			reg = pa2[linha_ficheiro_reg];
  
  
  			t = reg.t.tv_sec;
  			memset(&tm, 0, sizeof(struct tm));
  			localtime_r (&t, &tm);
  			strftime(time, sizeof(time), "%d/%m/%Y %H:%M:%S", &tm);
  			printf ("Data:%s %ld \n", time, reg.t.tv_sec);
  
  			linha_ficheiro_reg++;	
  			printf("linha de reg: %d\n",linha_ficheiro_reg);
    		break;
		}
	}
	
	env_ctlp();

}
	
void inicia_srv_ctlp1(){
	printf("servidor espera controlador\n");

	ma.mq_flags = 0;
	ma.mq_maxmsg = 3;
	ma.mq_msgsize = sizeof(msg);
	
	strcpy (msg.id, CTLA);	 

	printf("verifica porta\n");
	srv_vrfporta1();
	
	while(1){
	
		printf("verifica id\n");
		printf("<id> recebido. %s\n", msg.mtext);
		srv_vrfporta2();	
  	}	

  
  if (mq_unlink(SERVNAME) < 0) {
    perror("Servidor: Erro a eliminar queue servidor");
  }

}

/*-------------------------------------------------------------------------+
* 
* Funcao: cmd_cuti
*
+-------------------------------------------------------------------------*/
void cmd_cuti (void){
	int i;
	printf("\nSRV> executa <cuti>;; ja existem %d utilizadores\n", linha_ficheiro);
	
	printf("\nSRV>> bloqueia o mutex\n");
		pthread_mutex_lock(&mux);
	
	for(i = 0; i<= linha_ficheiro; i++){
		/*Testa se o id existe*/
		printf("\nSRV> id:%s e %s\n", pa[i].id, u1.id);
		if(strcmp(u1.id, pa[i].id) == 0){				
			printf("\nSRV> ja existe o <id>\n");
			strcpy(u1.cmd, "erro");
			printf("envia: %s\n", u1.cmd);
			if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
      			perror("Erro no sendto");
    		}
    		
			printf("\nSRV>> desbloqueia o mutex\n");
				pthread_mutex_unlock(&mux);
    		return;
		}
	}
		printf("portas: %s\n",u1.portas);
			for(int j = 0; j < 3; j++){
  				if ((u1.portas[j] == 'A' ) ||  (u1.portas[j] == 'B' ) || (u1.portas[j] == 'C' )){
					u.port[j] = '1';
					printf("acesso dado a uma porta\n");
					}else{
					u.port[j] = '0';
					printf("acesso negado a uma porta\n");
					}
			}
			printf("\nSRV> escreve no ficheiro\n");
			strcpy( u.id , u1.id);
			strcpy( u.nome , u1.nome);
	
			printf("%s\n%s\n%s\n", u.id, u.nome, u.port);
	
  			pa[linha_ficheiro]= u;
			linha_ficheiro++;
			printf("comando executado com sucesso\n");
			strcpy(u1.cmd, "comando executado com sucesso"); 
			if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
      			perror("Erro no sendto");
    		}
	
	printf("\nSRV>> desbloqueia o mutex\n");
		pthread_mutex_unlock(&mux);	    		
    		
return;
}
/*-------------------------------------------------------------------------+
| Function: cmd_luti - apenas como exemplo
+-------------------------------------------------------------------------*/ 
void cmd_luti (void){
	int i=0;
		
	printf("\nSRV> executa <luti>\n");
	
	printf("\nSRV>> bloqueia o mutex\n");
		pthread_mutex_lock(&mux);
	
	if(strcmp(u1.id, "0") == 0){
		printf("\nSRV> lista completa\n");
		for(i = 0; i< linha_ficheiro; i++){	
			printf("%s %s %s\n", pa[i].id,  pa[i].nome,  pa[i].port);
			strcpy(u1.id, pa[i].id);
			strcpy(u1.nome, pa[i].nome);
			strcpy(u1.tempo1, "");
			strcpy(u1.tempo2, "");
			strcpy(u1.estado, "");
			
			if (pa[i].port[0] == '1'){
				u1.portas[0] = 'A'; 
			}else{
				u1.portas[0] = 'a'; 
				}		
			if (pa[i].port[1] == '1'){
				u1.portas[1] = 'B'; 
			}else{
				u1.portas[1] = 'b'; 
			}
			if (pa[i].port[2] == '1' ){
				u1.portas[2] = 'C'; 
			}else{
				u1.portas[2] = 'c'; 
			}	
				
			if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
      			perror("Erro no sendto");
    		}
		}
		
		printf("\nSRV> nao existem mais utilizadores\n");
		strcpy(u1.cmd, "comando executado com sucesso"); 
		if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
      		perror("Erro no sendto");
    	}	
		
	}else{
		printf("\nSRV> percorre o ficheiro\n");
		for(i = 0; i<linha_ficheiro; i++){
			if(strcmp(pa[i].id, u1.id) == 0){				
				printf("%s %s %s\n", pa[i].id,  pa[i].nome,  pa[i].port);
				strcpy(u1.id, pa[i].id);
				strcpy(u1.nome, pa[i].nome);
				strcpy(u1.tempo1, "");
				strcpy(u1.tempo2, "");
				strcpy(u1.estado, "");
			
				if (pa[i].port[0] == '1'){
					u1.portas[0] = 'A'; 
				}else{
					u1.portas[0] = 'a'; 
				}		
				if (pa[i].port[1] == '1'){
					u1.portas[1] = 'B'; 
				}else{
					u1.portas[1] = 'b'; 
				}
				if (pa[i].port[2] == '1' ){
					u1.portas[2] = 'C'; 
				}else{
					u1.portas[2] = 'c'; 
				}	
				
				if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
      			perror("Erro no sendto");
    			}
			}	
		}
		strcpy(u1.cmd, "comando executado com sucesso"); 
		if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
      		perror("Erro no sendto");
    	}
	}
	
	
	printf("\nSRV>> desbloqueia o mutex\n");
		pthread_mutex_unlock(&mux);

}
/*-------------------------------------------------------------------------+
| Function: cmd_euti - apenas como exemplo
+-------------------------------------------------------------------------*/ 
void cmd_euti (void){
	int i, apagou_id = 0;
	printf("\nSRV>> executa <euti>\n");
	
	printf("\nSRV>> bloqueia o mutex\n");
		pthread_mutex_lock(&mux);
		
/*>> euti 0 - apaga todos os utilizadores*/
	if(strcmp(u1.id, "0") == 0){
		
		printf("\nSRV> apaga o ficheiro\n");	
			memset(u.id , '\0', sizeof(u.id));
			memset(u.nome , '\0', sizeof(u.nome));
			memset(u.port, 0, sizeof(u.port));
			
		for(i = 0; i<linha_ficheiro; i++){
			printf("%d\n",linha_ficheiro);
			printf( "%s\n",pa[i].id);
			printf( "%s\n",pa[i].nome);
			printf( "%s\n",pa[i].port);
			printf("/*********************************/\n");
  			pa[i]= u;			
			printf("%d\n",linha_ficheiro);
			printf( "%s\n",pa[i].id);
			printf( "%s\n",pa[i].nome);
			printf( "%s\n",pa[i].port);
			printf("/*********************************/\n");			
		}
		printf("\nSRV> nao existem mais utilizadores\n");
    	linha_ficheiro = 0;	
	}else{
/*>> euti <id> - apaga o utilizadores associado ao id*/	
		printf("\nSRV> percorre o ficheiro\n");
		for(i = 0; i<linha_ficheiro; i++){
			if(strcmp(pa[i].id, u1.id) == 0){				
				printf("\nSRV> apaga o utilizador com o id\n");
					memset(u.id , '\0', sizeof(u.id));
					memset(u.nome , '\0', sizeof(u.nome));
					memset(u.port, 0, sizeof(u.port));	
					pa[i]= u;
					apagou_id = 1;
			}	
			if(apagou_id ==1){
				pa[i] = pa[i+1];
			}		
		}
    	linha_ficheiro--;
	}
	
	strcpy(u1.cmd, "comando executado com sucesso"); 
		if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
      		perror("Erro no sendto");
    	}
	
	printf("\nSRV>> desbloqueia o mutex\n");
		pthread_mutex_unlock(&mux);
 
}
/*-------------------------------------------------------------------------+
| Function: cmd_muti - apenas como exemplo
+-------------------------------------------------------------------------*/ 
void cmd_muti (void)
{
	printf("\nSRV> executa <muti>\n");
	
	printf("\nSRV> bloqueia o mutex\n");
		pthread_mutex_lock(&mux);
		
		for(i = 0; i<linha_ficheiro; i++){
			if(strcmp(pa[i].id, u1.id) == 0){				
				printf("%s %s %s\n", pa[i].id,  pa[i].nome,  pa[i].port);
				
				for(int j = 0; j < 3; j++){
  					if ((u1.portas[j] == 'A' ) ||  (u1.portas[j] == 'B' ) || (u1.portas[j] == 'C' )){
						pa[i].port[j] = '1';
						printf("SRV> acesso dado a uma porta\n");
					}else{
						pa[i].port[j] = '0';
						printf("acesso negado a uma porta\n");
					}
				}
				printf("SRV > muda para portas para%s\n", pa[i].port);
	
				
				printf("\nSRV> escreve no ficheiro\n");				
  					
				strcpy(u1.cmd, "comando executado com sucesso"); 
				if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
      				perror("Erro no sendto");
    			}
    		}
		}	

		
		
	
	printf("\nSRV>> desbloqueia o mutex\n");
		pthread_mutex_unlock(&mux);	
}
/*-------------------------------------------------------------------------+
| Function: cmd_lac - listar 
+-------------------------------------------------------------------------*/ 
void cmd_lac (void){
	time_t t;
	time_t time1;
    time_t time2;
    time_t time3; 
	double diff1, diff2;
	struct tm t1 = {0}; // Inicializar a estrutura com zeros
	struct tm t2 = {0}; // Inicializar a estrutura com zeros
  	struct tm t3 = {0}; // Inicializar a estrutura com zeros
  	struct tm tm;
  	char time [50];
  	char portas[4];
  	char id[4];
	
	printf("\nSRV> executa <lac>\n");	
	
	printf("%s\n", u1.tempo1);
	printf("%s\n", u1.tempo2);
	
	
	strcpy(id, u1.id);
	strcpy(portas, u1.portas);

	for(i = 0; i < linha_ficheiro_reg; i++){
		reg = pa2[i];
	
		printf("id:%s	", reg.id);
  		printf("porta:%c	", reg.p);
  		
  
  		t = reg.t.tv_sec;
  		memset(&tm, 0, sizeof(struct tm));
  		localtime_r (&t, &tm);
  		strftime(time, sizeof(time), "%d/%m/%Y %H:%M:%S", &tm);
  		printf("Data:%s\n", time);
	
		
		printf("id:%s || portas:%s\n", portas, id);
		
		printf("reg.id:%s || reg.portas:%c\n", reg.id, reg.p);
		
		

    // Converter a hora para a struct tm
    sscanf(u1.tempo1, "%d/%d/%d %d:%d:%d", &t1.tm_mday, &t1.tm_mon, &t1.tm_year, &t1.tm_hour, &t1.tm_min, &t1.tm_sec);
	sscanf(u1.tempo2, "%d/%d/%d %d:%d:%d", &t2.tm_mday, &t2.tm_mon, &t2.tm_year, &t2.tm_hour, &t2.tm_min, &t2.tm_sec);
	sscanf(time, "%d/%d/%d %d:%d:%d", &t3.tm_mday, &t3.tm_mon, &t3.tm_year, &t3.tm_hour, &t3.tm_min, &t3.tm_sec);
	
	
    printf("Ano: t1:%d e t3%d\n", t1.tm_year, t3.tm_year);
	printf("Ano: t2:%d e t3%d\n", t2.tm_year, t3.tm_year);
	
	if(&t3.tm_year > &t1.tm_year){ 
		printf("t3 maior?\n");
	}
	
	if(&tm.tm_year < &t2.tm_year){ 
		printf("t2 maior?\n");
	}
	

    // Imprimir a struct tm
   	
    t1.tm_year -= 1900; // Ajustar o ano para o formato esperado pela struct tm
    t1.tm_mon -= 1;     // Ajustar o mês para o formato esperado pela struct tm

	t2.tm_year -= 1900; // Ajustar o ano para o formato esperado pela struct tm
    t2.tm_mon -= 1;     // Ajustar o mês para o formato esperado pela struct tm

    printf("Ano: %d\n", t1.tm_year + 1900);
    printf("Mês: %d\n", t1.tm_mon + 1);
    printf("Dia: %d\n", t1.tm_mday);
    printf("Hora: %d\n", t1.tm_hour);
    printf("Minuto: %d\n", t1.tm_min);
    printf("Segundo: %d\n", t1.tm_sec);
	
		
		
	// Converter as estruturas em valores de tempo em segundos
    	time1 = mktime(&t1);
    	time2 = mktime(&t2);
    	time3 = mktime(&tm);

    // Calcular a diferença em segundos
    diff1 = difftime(time3, time1);	
	diff2 = difftime(time2, time3);
		
	if (diff1 > 0){
        	printf("t3 é maior que t1 por %.0f segundos\n", diff1);
    		strcpy(u1.tempo1, "0");
    	}else{ 
    		if (diff1 < 0){
        		printf("t1 é maior que t3 por %.0f segundos\n", -diff1);
    		}else{
        		printf("t1 e t3 são iguais\n");
    		}
		}

	
	if (diff2 > 0){
     		printf("t2 é maior que t3 por %.0f segundos\n", diff2);
    		strcpy(u1.tempo2, "0");	
    	}else{
    		if(diff2 < 0) {
        		printf("t2 é maior que t3 por %.0f segundos\n", -diff2);
    		}else{	
    		    printf("t2 e t3 são iguais\n");
    		}
    	}	
	
		printf("tempo1: %s tempo2: %s\n", u1.tempo1 ,u1.tempo2);
		
		if((strcmp(reg.id, id) == 0) || (strcmp( "0", id) == 0)){
			if((strchr(portas, reg.p) != NULL) || (strcmp( "0", portas) == 0)){
				printf("ola %s ola:%s\n", u1.tempo1, u1.tempo2);
				if((strcmp("0", u1.tempo1) == 0) && (strcmp("0", u1.tempo2) == 0)){
		/*Atribui var*/		
					printf("manda\n");
					strcpy(u1.portas,"");
					u1.portas[0] = reg.p;
					strcpy(u1.id, reg.id);
					strcpy(u1.nome, time);
			/*manda para o integes*/	
					if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
      					perror("Erro no sendto");
    				}		
				}
			}		
		}
	}

	strcpy(u1.cmd, "comando executado com sucesso"); 
	printf("manda: %s\n", u1.cmd );	
		if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
      		perror("Erro no sendto");
    	}
	


}


/*-------------------------------------------------------------------------+
| Function: cmd_tser- apenas como exemplo
+-------------------------------------------------------------------------*/ 
void cmd_tser (void){
	printf("\nSRV> executa <tser>\n");
	printf("comando executado com sucesso\n");
	strcpy(u1.cmd, "comando executado com sucesso"); 
	if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
    	perror("Erro no sendto");
    }
	close(sd);
	unlink(SERVS);
	exit (0);
}
/*-------------------------------------------------------------------------+
| Function: cmd_cep - apenas como exemplo
+-------------------------------------------------------------------------*/ 
void cmd_cep (void){
	printf("SRV> executa cep\n");	

/*Atribui as variaveis  para a queue*/	
	ma2.mq_flags = 0;
	ma2.mq_maxmsg = 2;
	ma2.mq_msgsize = sizeof(msg2);
	
	printf("id: %s\n", u1.portas);
	
  	if(strcmp(u1.portas, "A") == 0){
  		strcpy(queue1_id, "/CLSERVA");  	
  	}else{
  		if(strcmp(u1.portas, "B") == 0){
  			strcpy(queue1_id, "/CLSERVB");  	
  		}else{
  			if(strcmp(u1.portas, "C") == 0){
  				strcpy(queue1_id, "/CLSERVC"); 	
  			}else{
  				printf("ERRO A ASSOCIAR PORTA\n");
  			}
  		}
  	}	
	
/*mostra o id da porta a usar*/	
	printf("id: %s\n", queue1_id);

/*copia as informações para a queue*/		
	strcpy (msg2.id, queue1_id);	 
	strcpy(msg2.mtext, "cep\0");	
	
/*associa a queen do lado do cli e do srv*/		 	  	
  	if ((mqidc2=mq_open(msg2.id, O_RDWR|O_CREAT, 0666, &ma2)) < 0) {
  		perror("Cliente: Erro a criar queue cliente");
  		exit(-1);
  	}
  	if ((mqids2=mq_open(msg2.id, O_RDWR)) < 0) {
    	perror("Cliente: Erro a associar a queue servidor");
    	exit(-1);
  	}
	
/*envia a informação para a queue*/	
      printf("Servidor vai enviar\n");
      if (mq_send(mqids2, (char *)&msg2, sizeof(msg2), 0) < 0) {
	perror("Servidor: erro a enviar mensagem");
      }
/*recebe a informação para a queue*/      
      printf("SRV> Servidor vai receber\n");
      if (mq_receive(mqidc2, (char *)&msg2, sizeof(msg2), NULL) < 0) {
    			perror("Cliente: erro a receber mensagem");
    		}else {
				printf("%s", msg2.mtext);
    		}
    
		
/*recebe da queue e mete na estrutura do socket*/	 
	strcpy(u1.nome, msg2.mtext); 
	printf("SRV> envia o estado %s (%s)\n", msg2.mtext, u1.cmd);
      	
	if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
    	perror("Erro no sendto");
    }
	    
    strcpy(u1.cmd, "comando executado com sucesso");
    
	if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
    	perror("Erro no sendto");
    }

}
/*-------------------------------------------------------------------------+
| Function: cmd_mep - mofificar estado
+-------------------------------------------------------------------------*/ 
void cmd_mep (void)
{
	printf("SRV> executa mep\n");	

/*Atribui as variaveis  para a queue*/	
	ma2.mq_flags = 0;
	ma2.mq_maxmsg = 2;
	ma2.mq_msgsize = sizeof(msg2);
	
	printf("id: %s\n", u1.portas);
	
  	if(strcmp(u1.portas, "A") == 0){
  		strcpy(queue1_id, "/CLSERVA");  	
  	}else{
  		if(strcmp(u1.portas, "B") == 0){
  			strcpy(queue1_id, "/CLSERVB");  	
  		}else{
  			if(strcmp(u1.portas, "C") == 0){
  				strcpy(queue1_id, "/CLSERVC"); 	
  			}else{
  				printf("ERRO A ASSOCIAR PORTA\n");
  			}
  		}
  	}	
	
/*mostra o id da porta a usar*/	
	printf("id: %s\n", queue1_id);

/*copia as informações para a queue*/		
	strcpy (msg2.id, queue1_id);	 
	sprintf(msg2.mtext, "mep %s", u1.estado);	
	
/*associa a queen do lado do cli e do srv*/		 	  	
  	if ((mqidc2=mq_open(msg2.id, O_RDWR|O_CREAT, 0666, &ma2)) < 0) {
  		perror("Cliente: Erro a criar queue cliente");
  		exit(-1);
  	}
  	if ((mqids2=mq_open(msg2.id, O_RDWR)) < 0) {
    	perror("Cliente: Erro a associar a queue servidor");
    	exit(-1);
  	}
	
/*envia a informação para a queue*/	
      printf("Servidor vai enviar\n");
      if (mq_send(mqids2, (char *)&msg2, sizeof(msg2), 0) < 0) {
	perror("Servidor: erro a enviar mensagem");
      }
/*recebe a informação para a queue*/      
      printf("SRV> Servidor vai receber\n");
      if (mq_receive(mqidc2, (char *)&msg2, sizeof(msg2), NULL) < 0) {
    			perror("Cliente: erro a receber mensagem");
    		}else {
				printf("%s", msg2.mtext);
    		}
    
		
/*recebe da queue e mete na estrutura do socket*/	 
	strcpy(u1.nome, msg2.mtext); 
	printf("SRV> envia o estado %s (%s)\n", msg2.mtext, u1.cmd);
      	
	if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
    	perror("Erro no sendto");
    }
	    
    strcpy(u1.cmd, "comando executado com sucesso");
    
	if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
    	perror("Erro no sendto");
    }

}
/*-------------------------------------------------------------------------+
| Function: cmd_tctl - controlador
+-------------------------------------------------------------------------*/ 
void cmd_tctl (void)
{
	printf("\nSRV> executa <tctl>");
	/*Atribui as variaveis  para a queue*/	
	ma2.mq_flags = 0;
	ma2.mq_maxmsg = 2;
	ma2.mq_msgsize = sizeof(msg2);
	
	printf("id: %s\n", u1.portas);
	
  	if(strcmp(u1.portas, "A") == 0){
  		strcpy(queue1_id, "/CLSERVA");  	
  	}else{
  		if(strcmp(u1.portas, "B") == 0){
  			strcpy(queue1_id, "/CLSERVB");  	
  		}else{
  			if(strcmp(u1.portas, "C") == 0){
  				strcpy(queue1_id, "/CLSERVC"); 	
  			}else{
  				printf("ERRO A ASSOCIAR PORTA\n");
  			}
  		}
  	}	
	
/*mostra o id da porta a usar*/	
	printf("id: %s\n", queue1_id);

/*copia as informações para a queue*/		
	strcpy (msg2.id, queue1_id);	
	sprintf(msg2.mtext, "tctl");	
	
/*associa a queen do lado do cli e do srv*/		 	  	
  	if ((mqids2=mq_open(msg2.id, O_RDWR)) < 0) {
    	perror("Cliente: Erro a associar a queue servidor");
    	exit(-1);
  	}
	
/*envia a informação para a queue*/	
      printf("Servidor vai enviar\n");
      if (mq_send(mqids2, (char *)&msg2, sizeof(msg2), 0) < 0) {
	perror("Servidor: erro a enviar mensagem");
      }
    
		
/*recebe da queue e mete na estrutura do socket*/	 
	strcpy(u1.nome, msg2.mtext); 
	printf("SRV> envia o estado %s (%s)\n", msg2.mtext, u1.cmd);
      	
	if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
    	perror("Erro no sendto");
    }
	    
    strcpy(u1.cmd, "comando executado com sucesso");
    
	if (sendto(sd, &u1, sizeof(u1), 0, (struct sockaddr *)&from, fromlen) < 0) {
    	perror("Erro no sendto");
    }

}
/*-------------------------------------------------------------------------+
| Function: cmd_tctl - controlador
+-------------------------------------------------------------------------*/ 
void monitor (void){

/*----------------- Procura comandos---------------------------*/
	int i;
	for (i = 0; i < NCOMMANDS; i++){ 
		printf("/**********************************/\n");
		if (strcmp(u1.cmd, commands[i].cmd_name) == 0) 
	  		break;
	}	  

/*----------------- Executa comandos---------------------------*/
	if (i < NCOMMANDS){
		commands[i].cmd_fnct ();
		close(sd);
		unlink(SERVS);
		/*munmap(pa, MSIZE);*/
  		close(mfd);
    } 
}

/*-------------------------------------------------------------------------+
| Function: main 
+-------------------------------------------------------------------------*/ 

void *integesth(void *){

	while(1){
		printf("\nSRV> inicia server-int.ges.\n");
			inicia_srv_intges();
		printf("\nSRV> executa o comando\n");		
				monitor();
	}
			
  
  return 0;
}

void inicia_thread(void){

	if (pthread_create(&thread_integes, NULL, integesth, NULL) != 0) {
		printf("Erro a criar thread_integes\n");
   	}
    	
}


/*-------------------------------------------------------------------------+
| Function: main 
+-------------------------------------------------------------------------*/ 
int main(){
	  	
  	printf("\nSRV>> cria ficheiro dos utilizadores\n");
		cria_ficheiro();
	
  	printf("\nSRV>> cria ficheiro dos registos\n");
		cria_ficheiro_reg();	
		
	printf("\nSRV>> cria mecaismos de sincronização\n");
		if (pthread_mutex_init(&mux, NULL) != 0) {
      		printf("Erro a inicializar mutex\n");
      		return -1;
  		}
	
	printf("\nSRV>> executa threads\n");
		inicia_thread();
    
    /*printf("\nSRV>> executa threads\n");
		signal(SIGKILL, termina);
    	*/
	printf("\nSRV>> inicia server-ctlp\n");
		inicia_srv_ctlp1();
	
	printf("\nSRV>> encerra threads\n");
		pthread_join(thread_integes, NULL);

return 0;
}
